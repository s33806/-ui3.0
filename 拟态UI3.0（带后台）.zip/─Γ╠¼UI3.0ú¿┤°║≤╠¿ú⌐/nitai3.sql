-- MySQL dump 10.13  Distrib 5.6.50, for Linux (x86_64)
--
-- Host: localhost    Database: nitai3
-- ------------------------------------------------------
-- Server version	5.6.50-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `xf_conf`
--

DROP TABLE IF EXISTS `xf_conf`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `xf_conf` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `web_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `web_keyword` text COLLATE utf8_unicode_ci,
  `web_desc` text COLLATE utf8_unicode_ci,
  `web_logo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `wangyi` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xf_conf`
--

LOCK TABLES `xf_conf` WRITE;
/*!40000 ALTER TABLE `xf_conf` DISABLE KEYS */;
INSERT INTO `xf_conf` VALUES (1,'小枫拟态UI3.0-原创拟态UI设计','小枫网络,小枫网络导航,小枫网络工作室,小枫拟态ui,拟态UI,新拟态,网页UI,简约个人主页,个人主页,导航','小枫拟态UI设计是一款简约平滑全开源的自适应个人主页','https://www.xfwl.club/favicon.ico','热歌榜');
/*!40000 ALTER TABLE `xf_conf` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xf_sites`
--

DROP TABLE IF EXISTS `xf_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `xf_sites` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `link` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `create_at` int(10) DEFAULT NULL,
  `status` int(1) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xf_sites`
--

LOCK TABLES `xf_sites` WRITE;
/*!40000 ALTER TABLE `xf_sites` DISABLE KEYS */;
INSERT INTO `xf_sites` VALUES (6,'小枫网络','https://www.xfwl.club',1648114722,1),(7,'H5音乐播放器','https://music.xfyun.club',1648114727,1),(8,'layui镜像站','https://layui.xfwl.club',1648114732,1);
/*!40000 ALTER TABLE `xf_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xf_user`
--

DROP TABLE IF EXISTS `xf_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `xf_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `age` int(10) DEFAULT '0',
  `address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `hobby` text COLLATE utf8_unicode_ci,
  `account` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `qq` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `wechat` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `avatar` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `create_at` int(10) DEFAULT NULL,
  `about` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xf_user`
--

LOCK TABLES `xf_user` WRITE;
/*!40000 ALTER TABLE `xf_user` DISABLE KEYS */;
INSERT INTO `xf_user` VALUES (1,'小枫',19,'江西·吉安','割韭菜','admin','e10adc3949ba59abbe56e057f20f883e','1809185784','https://admin.xfwl.club/image/xf_wx.png','https://q2.qlogo.cn/headimg_dl?dst_uin=1809185784&spec=100',1648359295,'此页面由原生HTML,CSS,JSjQuery开发!本站Ui以及代码由小枫原创,并且源图和代码全部开源供大家学习使用(严禁商用)。');
/*!40000 ALTER TABLE `xf_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'nitai3'
--

--
-- Dumping routines for database 'nitai3'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-04-02 16:08:53
