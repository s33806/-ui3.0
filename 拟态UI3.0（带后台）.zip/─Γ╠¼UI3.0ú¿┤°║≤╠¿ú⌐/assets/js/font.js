(function (doc, win) {
    var docEl = doc.documentElement;
    var resizeEvt = 'orientationchange' in window ? 'orientationchange' : 'resize';
    var recalc = function () {
        var clientWidth = docEl.clientWidth;
        if (!clientWidth)
            return;
        docEl.style.fontSize = (clientWidth > 640 ? 640 : clientWidth) / 320 * 20 + 'px';
    };
    // 不同浏览器resize事件处理机制不同  
    // 使用定时器延迟处理resize回调函数以降低重复响应  
    var recalcTimer = null;
    var delaycalc = function () {
        win.clearTimeout(recalcTimer);
        recalcTimer = win.setTimeout(recalc, 100);
    };
    // 移动端考虑事件注册函数的兼容性  
    if (!doc.addEventListener)
        return;
    win.addEventListener(resizeEvt, delaycalc, false);
    // DOMContentLoaded事件只在DOM文档树加载完毕触发，此处不用延迟处理  
    doc.addEventListener('DOMContentLoaded', recalc, false);
})(document, window);