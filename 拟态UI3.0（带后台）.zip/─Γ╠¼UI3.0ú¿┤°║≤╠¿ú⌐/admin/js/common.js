var baseurl = 'http://02.xfwl.club/';



$('#account_info').text(localStorage.getItem('account_info'));
$('#avatar_info').attr('src', localStorage.getItem('avatar_info'));

function logout()
{
    $.ajax({url : baseurl+"api/v1/logout", //ajax提交的地址
        type : 'post',//提交数据的方式
        success : function(res) {
            localStorage.removeItem('account_info');
            localStorage.removeItem('avatar_info');
            window.location.href='./login.html'
        }
    })
}