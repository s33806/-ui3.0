<?php
//000000000000
 exit();?>
a:12:{s:2:"id";i:1;s:8:"username";s:6:"小枫";s:3:"age";i:19;s:7:"address";s:14:"江西·吉安";s:5:"hobby";s:9:"割韭菜";s:7:"account";s:5:"admin";s:8:"password";s:32:"e10adc3949ba59abbe56e057f20f883e";s:2:"qq";s:10:"1809185784";s:6:"wechat";s:39:"https://admin.xfwl.club/image/xf_wx.png";s:6:"avatar";s:58:"https://q2.qlogo.cn/headimg_dl?dst_uin=1809185784&spec=100";s:9:"create_at";i:1648359295;s:5:"about";s:149:"此页面由原生HTML,CSS,JSjQuery开发!本站Ui以及代码由小枫原创,并且源图和代码全部开源供大家学习使用(严禁商用)。";}